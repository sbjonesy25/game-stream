Close Game Stream first. Run as your normal desktop user:
  bash uninstall-game-stream.sh
Preview with --dry-run. Add --purge-user-data to remove preferences/session/cache.
Settings and the source checkout/.venv are kept by default.
If a system package is installed, sudo is requested to remove it.
